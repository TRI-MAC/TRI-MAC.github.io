# Voltr Mobility Dataset

Synthetic meeting records for a fictional e-scooter company debating whether to expand into commercial fleet scooters. 50 employees, 1000 meetings, 18 months (Jan 2026 -- Jun 2027).

## Files

```
voltr-mobility/
├── meta.json                   # Company description, people roster, scenario context
├── calendar.csv                # All 1,000 meetings
├── outcomes.json               # Decision/outcome logs for ~712 meetings
├── transcripts/                # Full meeting transcripts (200 of 1,000)
│   ├── MTG-001.txt
│   ├── MTG-004.txt
│   └── ...
└── README.md
```

### meta.json

Company context and the full employee roster (50 people). Each person has a `name` (anonymised ID like `EMP-001`), `role`, and `personality` description. Use this to understand who's who.

### calendar.csv

One row per meeting. Columns:

| Column | Description |
|---|---|
| `meeting_id` | Unique ID (`MTG-001` .. `MTG-1000`) |
| `title` | Meeting title |
| `attendees` | Pipe-delimited employee IDs (`EMP-001\|EMP-004\|EMP-005`) |
| `date` | ISO 8601 datetime |
| `duration_minutes` | Length in minutes |
| `status` | `scheduled`, `rescheduled`, or `cancelled` |
| `original_date` | Original date if rescheduled, empty otherwise |
| `thread_ids` | Pipe-delimited topic tags |
| `tick_index` | Two-week time period index (0-38) |

### outcomes.json

Array of outcome logs. Not every meeting has one -- gaps are intentional. Each entry:

- `meeting_id` -- references `calendar.csv`
- `summary` -- what was decided or discussed
- `action_items` -- list of follow-ups (may be `null` for vague entries)
- `quality` -- `"crisp"` (detailed) or `"vague"` (brief/ambiguous)

### transcripts/

Plain-text meeting transcripts. Format:

```
Meeting: <title>
Date: <date>
Attendees: <comma-separated IDs>
---
[HH:MM:SS] EMP-XXX: <dialogue>
```

Only 200 of the 1,000 meetings have transcripts. Cancelled meetings have no transcripts.
